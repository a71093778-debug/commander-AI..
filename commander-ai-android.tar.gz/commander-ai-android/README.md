# Commander AI — Android App

A complete native Android voice assistant supporting Hindi & English, Bluetooth headsets, personal voice profiles, and offline speech recognition.

## Requirements

- Android Studio Hedgehog (2023.1.1) or newer
- Android SDK 34
- Kotlin 1.9.22
- Gradle 8.4
- Minimum device: Android 13 (API 33)

## Setup

1. Open Android Studio
2. File → Open → select the `commander-ai-android/` folder
3. Wait for Gradle sync to complete
4. Connect a device or start an emulator running Android 13+
5. Run → Run 'app'

## First Launch

On first launch:
1. The app will ask for permissions — grant all for full functionality
2. Go to **Settings → Notification Listener Access** and enable Commander AI
3. The voice assistant starts automatically and listens for **"Hello Commander"**

## Features

| Command | Example |
|---------|---------|
| Call a contact | "Hello Commander, call Rahul" |
| Open an app | "Hello Commander, open WhatsApp" |
| Read notifications | "Hello Commander, read notifications" |
| Read messages | "Hello Commander, read messages" |
| Missed calls | "Hello Commander, missed calls" |
| Battery status | "Hello Commander, battery" |
| Time and date | "Hello Commander, what time is it" |
| Flashlight | "Hello Commander, flashlight on/off" |
| Bluetooth status | "Hello Commander, bluetooth status" |
| Wi-Fi status | "Hello Commander, wifi status" |

## Screens

- **Home** — Large mic button, assistant toggle, quick status
- **Assistant** — Full-screen listening view with live transcript
- **Settings** — Wake word, language, audio, Bluetooth, notifications
- **Voice Profile** — Enroll your voice for speaker verification
- **Permissions** — Grant/review all required permissions

## Architecture

```
app/
├── ui/                     # Activities (Home, Assistant, Settings, VoiceProfile, Permissions)
├── service/                # VoiceAssistantService (foreground), CommanderNotificationService
├── manager/                # SpeechRecognitionManager, TextToSpeechManager,
│                           # BluetoothHeadsetManager, CommandProcessor,
│                           # VoiceProfileManager, SettingsManager
├── model/                  # Data classes (Command, VoiceProfile, NotificationInfo, …)
├── tile/                   # Quick Settings Tile
└── receiver/               # BootReceiver (auto-start on device boot)
```

## Permissions Explained

| Permission | Why |
|------------|-----|
| RECORD_AUDIO | Voice recognition |
| READ_CONTACTS | Call contacts by name |
| CALL_PHONE | Place phone calls |
| READ_CALL_LOG | Read missed calls |
| READ_SMS | Read incoming messages |
| POST_NOTIFICATIONS | Show foreground service notification |
| BLUETOOTH_CONNECT | Detect & route audio to headset |
| FOREGROUND_SERVICE_MICROPHONE | Run mic in background |
| RECEIVE_BOOT_COMPLETED | Auto-start after reboot |

All permissions are user-controlled. No data leaves the device.

## Customization

- **Wake word**: Change in Settings or directly in `SettingsManager.kt` default value
- **Languages**: Toggle Hindi / English in Settings
- **Speech rate/pitch**: Sliders in Settings
- **Voice profile threshold**: Adjust `MATCH_THRESHOLD` in `VoiceProfileManager.kt`

## Bluetooth Audio

When a Bluetooth SCO headset is connected, the app automatically routes TTS responses through it. The routing uses `AudioManager.startBluetoothSco()` — standard Android API, no root required.

## Voice Profile

Enrollment records 5 short audio samples and extracts spectral energy features for lightweight on-device speaker verification. For production-quality speaker ID, the `verifyVoice()` method in `VoiceProfileManager.kt` can be replaced with a TFLite model inference call.

## Security

- All processing is on-device
- No network calls, no analytics, no tracking
- Voice profile data stored in encrypted SharedPreferences
- Only official Android SDK APIs used

# Commander AI — Static Analysis Report

Generated: June 2026 (pre-build manual review)

---

## Summary

| Category | Issues Found | Fixed |
|---|---|---|
| XML syntax errors | 1 | ✅ |
| ViewBinding mismatches | 4 | ✅ |
| Deprecated API (minSdk 33) | 2 | ✅ |
| Android 14 foreground service | 1 | ✅ |
| SecurityException guards | 2 | ✅ |
| Unused imports | 2 | ✅ |
| Missing layout IDs | 2 | ✅ |
| Signing configuration | 1 | ✅ |

---

## Issues Fixed

### 1. `themes.xml` — XML Parse Error
**File**: `app/src/main/res/values/themes.xml`  
**Issue**: Dark theme `android:navigationBarColor` item closed with `</color>` instead of `</item>`. Breaks resource compilation entirely.  
**Fix**: Changed to `</item>`.

---

### 2. `VoiceAssistantService.kt` — Android 14 Foreground Service Crash
**File**: `app/src/main/kotlin/…/service/VoiceAssistantService.kt`  
**Issue**: On Android 14 (API 34), `startForeground(id, notification)` with `android:foregroundServiceType="microphone"` in the manifest throws `MissingForegroundServiceTypeException` if the service type is not also passed in code.  
**Fix**:
```kotlin
if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
    startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
} else {
    startForeground(NOTIFICATION_ID, notification)
}
```

---

### 3. `MainActivity.kt` — Wrong API on ExtendedFloatingActionButton → FloatingActionButton
**File**: `app/src/main/kotlin/…/ui/MainActivity.kt`  
**Issue**:
- `binding.fabMic.setImageResource(R.drawable.ic_mic)` — `setImageResource()` is not on `ExtendedFloatingActionButton` (which extends `MaterialButton`).
- `binding.fabMic.setBackgroundColor(...)` — loses Material Design shape and ripple.
**Fix**: Changed layout widget to `FloatingActionButton` (standard circular button), changed code to:
```kotlin
binding.fabMic.setImageDrawable(ContextCompat.getDrawable(this, iconRes))
binding.fabMic.backgroundTintList = ColorStateList.valueOf(getColor(colorRes))
```

---

### 4. `PermissionsActivity.kt` — ViewBinding to 0×0dp Hidden Views
**File**: `app/src/main/kotlin/…/ui/PermissionsActivity.kt`  
**Issue**: Status TextViews `tvMicStatus`, `tvContactsStatus`, etc. were declared in the layout as 0dp×0dp (invisible), so setting their text had no visual effect. The `<include>` references were also incorrectly accessed.  
**Fix**: Completely rewrote `activity_permissions.xml` with properly-sized, visible rows for each of the 7 permissions. Each row displays a label, description, and a color-coded ✓/✗ status `TextView`.

---

### 5. `activity_settings.xml` — Missing Binding IDs
**File**: `app/src/main/res/layout/activity_settings.xml`  
**Issue**: `SettingsActivity.kt` referenced `binding.switchContinuous` and `binding.switchVoiceProfile` but neither ID existed in the layout — compile error.  
**Fix**: Added a new **Behavior** card section with both switches (Continuous Listening, Voice Profile Recognition).

---

### 6. `CommandProcessor.kt` — Deprecated `WifiManager.connectionInfo`
**File**: `app/src/main/kotlin/…/manager/CommandProcessor.kt`  
**Issue**: `wifiManager.connectionInfo` is deprecated since API 31. Accessing it without a check on Android 13+ generates a lint error and may return incorrect data.  
**Fix**: Primary connected-state check via `ConnectivityManager.getNetworkCapabilities()`. SSID lookup uses the deprecated API only as a secondary, explicitly suppressed with `@Suppress("DEPRECATION")` and wrapped in try-catch.

---

### 7. `BluetoothHeadsetManager.kt` — SecurityException on `connectedDevices`
**File**: `app/src/main/kotlin/…/manager/BluetoothHeadsetManager.kt`  
**Issue**: `bluetoothHeadset?.connectedDevices` requires `BLUETOOTH_CONNECT` at runtime on Android 12+; unguarded call crashes with `SecurityException`.  
**Fix**: On Android 12+ (API 31+), uses `AudioManager.getDevices(GET_DEVICES_OUTPUTS)` to check for BT SCO/A2DP devices (no runtime permission needed). Falls back to `connectedDevices` on older APIs with a `SecurityException` guard.

---

### 8. Unused Imports in `VoiceAssistantService.kt`
**File**: `app/src/main/kotlin/…/service/VoiceAssistantService.kt`  
**Issue**: `import android.media.AudioRecord` and `import android.media.MediaRecorder` were imported but never used.  
**Fix**: Removed both unused imports.

---

## Android 13 / Android 14 Compatibility

| Feature | Android 13 (API 33) | Android 14 (API 34) |
|---|---|---|
| Foreground service type in code | Not required | ✅ Required — fixed |
| `RECEIVER_NOT_EXPORTED` on `registerReceiver` | ✅ Required — implemented | ✅ |
| `POST_NOTIFICATIONS` permission | ✅ Required — in manifest | ✅ |
| `BLUETOOTH_CONNECT` runtime check | ✅ Required — guarded | ✅ |
| `WifiManager.connectionInfo` | Works (deprecated) | Works (suppressed) |
| Exact alarms (`SCHEDULE_EXACT_ALARM`) | Not used | N/A |

---

## Permissions Verification

| Permission | Purpose | Group |
|---|---|---|
| `RECORD_AUDIO` | Wake word + voice recognition | Dangerous |
| `READ_CONTACTS` | Look up contact names for calling | Dangerous |
| `CALL_PHONE` | Initiate phone calls | Dangerous |
| `READ_CALL_LOG` | Read missed calls | Dangerous |
| `READ_SMS` | Read incoming messages | Dangerous |
| `POST_NOTIFICATIONS` | Foreground service notification | Dangerous (API 33+) |
| `BLUETOOTH_CONNECT` | BT headset routing | Dangerous (API 31+) |
| `BLUETOOTH_SCAN` | BT device scan | Dangerous (API 31+) |
| `ACCESS_WIFI_STATE` | Wi-Fi enabled check | Normal |
| `ACCESS_NETWORK_STATE` | Network connectivity check | Normal |
| `CAMERA` | Flashlight / torch control | Dangerous |
| `FOREGROUND_SERVICE` | Foreground service | Normal |
| `FOREGROUND_SERVICE_MICROPHONE` | Mic foreground type | Normal |
| `RECEIVE_BOOT_COMPLETED` | Auto-start on boot | Normal |
| `VIBRATE` | Haptic feedback | Normal |

All permissions are declared in `AndroidManifest.xml`. Dangerous permissions are checked at runtime in `PermissionsActivity`.

---

## Build Configuration

### Release Build
- `minifyEnabled true` — R8 minification enabled
- `shrinkResources true` — unused resources stripped
- `proguardFiles` — includes `proguard-android-optimize.txt`
- Signing reads from `keystore.properties` (gitignored)

### Lint
- `abortOnError false` — warnings do not break build
- HTML + XML reports at `app/build/reports/`

---

## Items Requiring Manual Action

1. **Notification Listener Access** — must be granted by the user in System Settings → Special App Access → Notification Access. There is no runtime API to request this.
2. **Keystore Setup** — copy `keystore.properties.template` → `keystore.properties`, generate a keystore with `keytool`, and fill in credentials before running a release build.
3. **Launcher Icons (PNG density variants)** — adaptive icons are provided as XML (anydpi-v26). For full Google Play compliance, generate and add PNG variants for `mipmap-mdpi`, `mipmap-hdpi`, `mipmap-xhdpi`, `mipmap-xxhdpi`, `mipmap-xxxhdpi` using Android Studio's Image Asset Studio.

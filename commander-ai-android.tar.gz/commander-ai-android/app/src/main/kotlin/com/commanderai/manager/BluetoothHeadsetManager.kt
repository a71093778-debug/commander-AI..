package com.commanderai.manager

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothHeadset
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.os.Build
import android.util.Log

class BluetoothHeadsetManager(private val context: Context) {

    private val bluetoothManager: BluetoothManager =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager.adapter
    private val audioManager: AudioManager =
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private var bluetoothHeadset: BluetoothHeadset? = null
    private var isReceiverRegistered = false
    private var listener: BluetoothHeadsetListener? = null

    interface BluetoothHeadsetListener {
        fun onHeadsetConnected()
        fun onHeadsetDisconnected()
        fun onAudioRouteChanged(throughBluetooth: Boolean)
    }

    private val profileListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            if (profile == BluetoothProfile.HEADSET) {
                bluetoothHeadset = proxy as BluetoothHeadset
                Log.d(TAG, "BluetoothHeadset profile connected")
            }
        }
        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.HEADSET) {
                bluetoothHeadset = null
                Log.d(TAG, "BluetoothHeadset profile disconnected")
            }
        }
    }

    private val headsetReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED -> {
                    val state = intent.getIntExtra(
                        BluetoothProfile.EXTRA_STATE,
                        BluetoothProfile.STATE_DISCONNECTED
                    )
                    when (state) {
                        BluetoothProfile.STATE_CONNECTED -> {
                            Log.d(TAG, "Headset connected")
                            listener?.onHeadsetConnected()
                            routeAudioToBluetooth()
                        }
                        BluetoothProfile.STATE_DISCONNECTED -> {
                            Log.d(TAG, "Headset disconnected")
                            listener?.onHeadsetDisconnected()
                            stopBluetoothAudio()
                        }
                    }
                }
                AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED -> {
                    val state = intent.getIntExtra(
                        AudioManager.EXTRA_SCO_AUDIO_STATE,
                        AudioManager.SCO_AUDIO_STATE_DISCONNECTED
                    )
                    listener?.onAudioRouteChanged(state == AudioManager.SCO_AUDIO_STATE_CONNECTED)
                }
            }
        }
    }

    fun initialize(listener: BluetoothHeadsetListener) {
        this.listener = listener
        try {
            bluetoothAdapter?.getProfileProxy(context, profileListener, BluetoothProfile.HEADSET)
        } catch (e: SecurityException) {
            Log.e(TAG, "Bluetooth permission denied during initialize", e)
        }
        registerReceiver()
    }

    private fun registerReceiver() {
        if (isReceiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(BluetoothHeadset.ACTION_CONNECTION_STATE_CHANGED)
            addAction(AudioManager.ACTION_SCO_AUDIO_STATE_UPDATED)
        }
        context.registerReceiver(headsetReceiver, filter)
        isReceiverRegistered = true
    }

    fun isBluetoothEnabled(): Boolean = bluetoothAdapter?.isEnabled == true

    /**
     * Checks whether a Bluetooth headset/SCO device is connected.
     * On Android 13+ we query AudioDeviceInfo (no BLUETOOTH_CONNECT needed for output devices).
     * On earlier APIs we query BluetoothHeadset.connectedDevices with SecurityException guard.
     */
    fun isHeadsetConnected(): Boolean {
        if (bluetoothAdapter == null || !bluetoothAdapter.isEnabled) return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            devices.any {
                it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                        it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP
            }
        } else {
            try {
                bluetoothHeadset?.connectedDevices?.isNotEmpty() == true
            } catch (e: SecurityException) {
                Log.e(TAG, "BLUETOOTH_CONNECT permission denied", e)
                false
            }
        }
    }

    fun getConnectedHeadsetName(): String? {
        if (!isHeadsetConnected()) return null
        return try {
            bluetoothHeadset?.connectedDevices?.firstOrNull()?.name
        } catch (e: SecurityException) {
            Log.e(TAG, "Permission denied accessing Bluetooth device name", e)
            "Bluetooth Headset"
        }
    }

    fun routeAudioToBluetooth() {
        if (!isHeadsetConnected()) return
        try {
            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            audioManager.startBluetoothSco()
            audioManager.isBluetoothScoOn = true
            Log.d(TAG, "Routed audio to Bluetooth SCO")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to route audio to Bluetooth", e)
        }
    }

    fun stopBluetoothAudio() {
        try {
            audioManager.stopBluetoothSco()
            audioManager.isBluetoothScoOn = false
            audioManager.mode = AudioManager.MODE_NORMAL
        } catch (e: Exception) {
            Log.e(TAG, "Failed to stop Bluetooth audio", e)
        }
    }

    fun getStatusText(): String {
        if (bluetoothAdapter == null) return "Bluetooth not supported"
        if (!bluetoothAdapter.isEnabled) return "Bluetooth is off"
        val name = getConnectedHeadsetName()
        return if (name != null) "Bluetooth headset connected: $name" else "Bluetooth is on, no headset connected"
    }

    fun release() {
        if (isReceiverRegistered) {
            try { context.unregisterReceiver(headsetReceiver) } catch (_: Exception) {}
            isReceiverRegistered = false
        }
        try {
            bluetoothAdapter?.closeProfileProxy(BluetoothProfile.HEADSET, bluetoothHeadset)
        } catch (_: Exception) {}
        bluetoothHeadset = null
        stopBluetoothAudio()
    }

    companion object {
        private const val TAG = "BluetoothHeadsetManager"
    }
}

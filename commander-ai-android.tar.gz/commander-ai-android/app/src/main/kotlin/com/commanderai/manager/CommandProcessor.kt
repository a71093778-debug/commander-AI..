package com.commanderai.manager

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.Telephony
import android.util.Log
import com.commanderai.model.*
import com.commanderai.service.CommanderNotificationService
import java.text.SimpleDateFormat
import java.util.*

class CommandProcessor(private val context: Context) {

    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private var isTorchOn = false

    fun parseCommand(text: String): Command {
        val lower = text.lowercase().trim()
        return when {
            lower.contains("call ") ->
                Command(CommandType.CALL_CONTACT, text, extractAfter(lower, "call "))

            lower.contains("open ") && !lower.contains("open notification") ->
                Command(CommandType.OPEN_APP, text, extractAfter(lower, "open "))

            lower.contains("notification") || lower.contains("notifications") ->
                Command(CommandType.READ_NOTIFICATIONS, text)

            lower.contains("sms") || lower.contains("message") ->
                Command(CommandType.READ_SMS, text)

            lower.contains("missed call") ->
                Command(CommandType.READ_MISSED_CALLS, text)

            lower.contains("battery") || lower.contains("charge") ->
                Command(CommandType.BATTERY_STATUS, text)

            lower.contains("time") || lower.contains("date") || lower.contains("day") ->
                Command(CommandType.TIME_DATE, text)

            (lower.contains("flash") || lower.contains("torch") || lower.contains("light")) &&
                    (lower.contains(" on") || lower.contains("turn on")) ->
                Command(CommandType.FLASHLIGHT_ON, text)

            (lower.contains("flash") || lower.contains("torch") || lower.contains("light")) &&
                    (lower.contains(" off") || lower.contains("turn off")) ->
                Command(CommandType.FLASHLIGHT_OFF, text)

            lower.contains("bluetooth") ->
                Command(CommandType.BLUETOOTH_STATUS, text)

            lower.contains("wifi") || lower.contains("wi-fi") || lower.contains("internet") ->
                Command(CommandType.WIFI_STATUS, text)

            else -> Command(CommandType.UNKNOWN, text)
        }
    }

    fun execute(command: Command): CommandResult = when (command.type) {
        CommandType.CALL_CONTACT       -> callContact(command.parameter ?: "")
        CommandType.OPEN_APP           -> openApp(command.parameter ?: "")
        CommandType.READ_NOTIFICATIONS -> readNotifications()
        CommandType.READ_SMS           -> readSms()
        CommandType.READ_MISSED_CALLS  -> readMissedCalls()
        CommandType.BATTERY_STATUS     -> getBatteryStatus()
        CommandType.TIME_DATE          -> getTimeDate()
        CommandType.FLASHLIGHT_ON      -> setFlashlight(true)
        CommandType.FLASHLIGHT_OFF     -> setFlashlight(false)
        CommandType.FLASHLIGHT_TOGGLE  -> setFlashlight(!isTorchOn)
        CommandType.BLUETOOTH_STATUS   -> getBluetoothStatus()
        CommandType.WIFI_STATUS        -> getWifiStatus()
        CommandType.UNKNOWN            -> CommandResult(false, "Sorry, I did not understand that command.")
    }

    // ─── Commands ────────────────────────────────────────────────────────────

    private fun callContact(name: String): CommandResult {
        if (name.isBlank()) return CommandResult(false, "Please say a contact name to call.")
        return try {
            val contact = findContact(name)
            if (contact != null) {
                val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:${contact.phoneNumber}"))
                    .apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
                context.startActivity(intent)
                CommandResult(true, "Calling ${contact.name}")
            } else {
                CommandResult(false, "Contact $name not found.")
            }
        } catch (e: SecurityException) {
            CommandResult(false, "Call permission not granted.")
        } catch (e: Exception) {
            Log.e(TAG, "Error calling contact", e)
            CommandResult(false, "Could not make the call.")
        }
    }

    private fun findContact(name: String): ContactInfo? = try {
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                ContactInfo(
                    cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)),
                    cursor.getString(cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER))
                )
            } else null
        }
    } catch (e: Exception) {
        Log.e(TAG, "Error finding contact", e)
        null
    }

    private fun openApp(appName: String): CommandResult {
        if (appName.isBlank()) return CommandResult(false, "Please say an app name to open.")
        return try {
            val pm = context.packageManager
            val match = pm.getInstalledApplications(0).find { app ->
                pm.getApplicationLabel(app).toString().lowercase().contains(appName.lowercase())
            }
            val launchIntent = match?.let { pm.getLaunchIntentForPackage(it.packageName) }
            if (launchIntent != null) {
                launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                context.startActivity(launchIntent)
                CommandResult(true, "Opening ${pm.getApplicationLabel(match!!)}")
            } else {
                CommandResult(false, "App $appName not found on this device.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error opening app", e)
            CommandResult(false, "Could not open $appName.")
        }
    }

    private fun readNotifications(): CommandResult {
        val notifications = CommanderNotificationService.getActiveNotifications()
        if (notifications.isEmpty()) return CommandResult(true, "You have no new notifications.")
        val sb = StringBuilder("You have ${notifications.size} notification")
        if (notifications.size > 1) sb.append("s")
        sb.append(". ")
        notifications.take(5).forEach { n ->
            sb.append("From ${n.appName}: ")
            n.title?.let { sb.append("$it. ") }
            n.text?.let { sb.append("$it. ") }
        }
        if (notifications.size > 5) sb.append("And ${notifications.size - 5} more.")
        return CommandResult(true, sb.toString())
    }

    private fun readSms(): CommandResult = try {
        val messages = getLatestSms(3)
        if (messages.isEmpty()) {
            CommandResult(true, "You have no recent messages.")
        } else {
            val sb = StringBuilder("You have ${messages.size} recent message")
            if (messages.size > 1) sb.append("s")
            sb.append(". ")
            messages.forEach { sb.append("From ${it.sender}: ${it.body}. ") }
            CommandResult(true, sb.toString())
        }
    } catch (e: SecurityException) {
        CommandResult(false, "SMS permission not granted.")
    } catch (e: Exception) {
        Log.e(TAG, "Error reading SMS", e)
        CommandResult(false, "Could not read messages.")
    }

    private fun getLatestSms(limit: Int): List<SmsMessage> {
        val messages = mutableListOf<SmsMessage>()
        context.contentResolver.query(
            Telephony.Sms.Inbox.CONTENT_URI,
            arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.BODY, Telephony.Sms.DATE),
            null, null,
            "${Telephony.Sms.DATE} DESC LIMIT $limit"
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                messages.add(
                    SmsMessage(
                        sender = resolveNumber(cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.ADDRESS))),
                        body = cursor.getString(cursor.getColumnIndexOrThrow(Telephony.Sms.BODY)),
                        timestamp = cursor.getLong(cursor.getColumnIndexOrThrow(Telephony.Sms.DATE))
                    )
                )
            }
        }
        return messages
    }

    private fun readMissedCalls(): CommandResult = try {
        val calls = getMissedCalls(5)
        if (calls.isEmpty()) {
            CommandResult(true, "You have no missed calls.")
        } else {
            val sb = StringBuilder("You have ${calls.size} missed call")
            if (calls.size > 1) sb.append("s")
            sb.append(". ")
            calls.forEach { sb.append("From ${it.name ?: it.number}. ") }
            CommandResult(true, sb.toString())
        }
    } catch (e: SecurityException) {
        CommandResult(false, "Call log permission not granted.")
    } catch (e: Exception) {
        Log.e(TAG, "Error reading missed calls", e)
        CommandResult(false, "Could not read missed calls.")
    }

    private fun getMissedCalls(limit: Int): List<MissedCall> {
        val calls = mutableListOf<MissedCall>()
        context.contentResolver.query(
            CallLog.Calls.CONTENT_URI,
            arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.CACHED_NAME, CallLog.Calls.DATE),
            "${CallLog.Calls.TYPE} = ?",
            arrayOf(CallLog.Calls.MISSED_TYPE.toString()),
            "${CallLog.Calls.DATE} DESC LIMIT $limit"
        )?.use { cursor ->
            while (cursor.moveToNext()) {
                calls.add(
                    MissedCall(
                        number = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.NUMBER)),
                        name = cursor.getString(cursor.getColumnIndexOrThrow(CallLog.Calls.CACHED_NAME))?.ifBlank { null },
                        timestamp = cursor.getLong(cursor.getColumnIndexOrThrow(CallLog.Calls.DATE))
                    )
                )
            }
        }
        return calls
    }

    private fun getBatteryStatus(): CommandResult = try {
        val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val charging = if (bm.isCharging) "charging" else "not charging"
        CommandResult(true, "Battery is at $level percent and is $charging.")
    } catch (e: Exception) {
        CommandResult(false, "Could not get battery status.")
    }

    private fun getTimeDate(): CommandResult {
        val now = Calendar.getInstance()
        val time = SimpleDateFormat("h:mm a", Locale.ENGLISH).format(now.time)
        val date = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.ENGLISH).format(now.time)
        return CommandResult(true, "The time is $time on $date.")
    }

    private fun setFlashlight(on: Boolean): CommandResult = try {
        val cameraId = cameraManager.cameraIdList.firstOrNull()
            ?: return CommandResult(false, "No camera found.")
        cameraManager.setTorchMode(cameraId, on)
        isTorchOn = on
        CommandResult(true, if (on) "Flashlight is on." else "Flashlight is off.")
    } catch (e: Exception) {
        Log.e(TAG, "Error setting flashlight", e)
        CommandResult(false, "Could not control the flashlight.")
    }

    private fun getBluetoothStatus(): CommandResult = try {
        val adapter = android.bluetooth.BluetoothAdapter.getDefaultAdapter()
        when {
            adapter == null -> CommandResult(true, "Bluetooth is not supported on this device.")
            !adapter.isEnabled -> CommandResult(true, "Bluetooth is turned off.")
            else -> {
                // BLUETOOTH_CONNECT permission required on Android 12+
                val pairedCount = try {
                    adapter.bondedDevices?.size ?: 0
                } catch (e: SecurityException) { 0 }
                CommandResult(true, "Bluetooth is on. $pairedCount paired device${if (pairedCount != 1) "s" else ""}.")
            }
        }
    } catch (e: Exception) {
        CommandResult(false, "Could not get Bluetooth status.")
    }

    /**
     * WiFi status — uses ConnectivityManager (modern API) for connected state.
     * WifiManager.connectionInfo is deprecated since API 31; the SSID lookup is
     * suppressed intentionally and falls back to "connected" if unavailable.
     */
    private fun getWifiStatus(): CommandResult = try {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = cm.getNetworkCapabilities(network)
        val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true

        if (isWifi) {
            // Attempt SSID via deprecated WifiManager — still functional on API 33/34
            // with ACCESS_FINE_LOCATION or ACCESS_WIFI_STATE; gracefully falls back.
            @Suppress("DEPRECATION")
            val ssid = try {
                val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                wm.connectionInfo?.ssid
                    ?.replace("\"", "")
                    ?.takeIf { it.isNotBlank() && it != "<unknown ssid>" }
            } catch (_: Exception) { null }

            CommandResult(true, if (ssid != null) "Wi-Fi is connected to $ssid." else "Wi-Fi is connected.")
        } else {
            val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            CommandResult(true, if (!wm.isWifiEnabled) "Wi-Fi is turned off." else "Wi-Fi is on but not connected.")
        }
    } catch (e: Exception) {
        Log.e(TAG, "Error getting WiFi status", e)
        CommandResult(false, "Could not get Wi-Fi status.")
    }

    private fun resolveNumber(number: String): String = try {
        context.contentResolver.query(
            Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)),
            arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME),
            null, null, null
        )?.use { c -> if (c.moveToFirst()) c.getString(0) else number } ?: number
    } catch (_: Exception) { number }

    private fun extractAfter(text: String, prefix: String): String = text.substringAfter(prefix).trim()

    companion object {
        private const val TAG = "CommandProcessor"
    }
}

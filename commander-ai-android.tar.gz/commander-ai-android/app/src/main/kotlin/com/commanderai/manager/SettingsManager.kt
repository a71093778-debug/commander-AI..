package com.commanderai.manager

import android.content.Context
import android.content.SharedPreferences
import com.commanderai.model.AppSettings

class SettingsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    fun getSettings(): AppSettings = AppSettings(
        isAssistantEnabled = prefs.getBoolean(KEY_ASSISTANT_ENABLED, true),
        wakeWord = prefs.getString(KEY_WAKE_WORD, "hello commander") ?: "hello commander",
        useHindi = prefs.getBoolean(KEY_USE_HINDI, true),
        useEnglish = prefs.getBoolean(KEY_USE_ENGLISH, true),
        useBluetooth = prefs.getBoolean(KEY_USE_BLUETOOTH, true),
        voiceProfileEnabled = prefs.getBoolean(KEY_VOICE_PROFILE_ENABLED, false),
        startOnBoot = prefs.getBoolean(KEY_START_ON_BOOT, true),
        speakNotifications = prefs.getBoolean(KEY_SPEAK_NOTIFICATIONS, true),
        continuousListening = prefs.getBoolean(KEY_CONTINUOUS_LISTENING, true),
        offlineSpeechPreferred = prefs.getBoolean(KEY_OFFLINE_SPEECH, true),
        speechRate = prefs.getFloat(KEY_SPEECH_RATE, 1.0f),
        speechPitch = prefs.getFloat(KEY_SPEECH_PITCH, 1.0f)
    )

    fun saveSettings(settings: AppSettings) {
        prefs.edit().apply {
            putBoolean(KEY_ASSISTANT_ENABLED, settings.isAssistantEnabled)
            putString(KEY_WAKE_WORD, settings.wakeWord)
            putBoolean(KEY_USE_HINDI, settings.useHindi)
            putBoolean(KEY_USE_ENGLISH, settings.useEnglish)
            putBoolean(KEY_USE_BLUETOOTH, settings.useBluetooth)
            putBoolean(KEY_VOICE_PROFILE_ENABLED, settings.voiceProfileEnabled)
            putBoolean(KEY_START_ON_BOOT, settings.startOnBoot)
            putBoolean(KEY_SPEAK_NOTIFICATIONS, settings.speakNotifications)
            putBoolean(KEY_CONTINUOUS_LISTENING, settings.continuousListening)
            putBoolean(KEY_OFFLINE_SPEECH, settings.offlineSpeechPreferred)
            putFloat(KEY_SPEECH_RATE, settings.speechRate)
            putFloat(KEY_SPEECH_PITCH, settings.speechPitch)
            apply()
        }
    }

    fun isAssistantEnabled(): Boolean = prefs.getBoolean(KEY_ASSISTANT_ENABLED, true)

    fun setAssistantEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_ASSISTANT_ENABLED, enabled).apply()
    }

    fun getWakeWord(): String =
        prefs.getString(KEY_WAKE_WORD, "hello commander") ?: "hello commander"

    fun isVoiceProfileEnabled(): Boolean = prefs.getBoolean(KEY_VOICE_PROFILE_ENABLED, false)

    fun setVoiceProfileEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_VOICE_PROFILE_ENABLED, enabled).apply()
    }

    fun isStartOnBoot(): Boolean = prefs.getBoolean(KEY_START_ON_BOOT, true)

    companion object {
        private const val PREFS_NAME = "commander_ai_prefs"
        private const val KEY_ASSISTANT_ENABLED = "assistant_enabled"
        private const val KEY_WAKE_WORD = "wake_word"
        private const val KEY_USE_HINDI = "use_hindi"
        private const val KEY_USE_ENGLISH = "use_english"
        private const val KEY_USE_BLUETOOTH = "use_bluetooth"
        private const val KEY_VOICE_PROFILE_ENABLED = "voice_profile_enabled"
        private const val KEY_START_ON_BOOT = "start_on_boot"
        private const val KEY_SPEAK_NOTIFICATIONS = "speak_notifications"
        private const val KEY_CONTINUOUS_LISTENING = "continuous_listening"
        private const val KEY_OFFLINE_SPEECH = "offline_speech"
        private const val KEY_SPEECH_RATE = "speech_rate"
        private const val KEY_SPEECH_PITCH = "speech_pitch"
    }
}

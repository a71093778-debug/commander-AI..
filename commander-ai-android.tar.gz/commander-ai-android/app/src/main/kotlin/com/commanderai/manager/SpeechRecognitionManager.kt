package com.commanderai.manager

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import java.util.Locale

class SpeechRecognitionManager(
    private val context: Context,
    private val settingsManager: SettingsManager
) {

    private var speechRecognizer: SpeechRecognizer? = null
    private var listener: SpeechListener? = null
    private var isListening = false
    private var wakeWordMode = false
    private var wakeWord = "hello commander"

    interface SpeechListener {
        fun onWakeWordDetected()
        fun onCommandRecognized(text: String)
        fun onPartialResult(text: String)
        fun onError(error: String)
        fun onListeningStarted()
        fun onListeningEnded()
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            isListening = true
            listener?.onListeningStarted()
            Log.d(TAG, "Ready for speech")
        }

        override fun onBeginningOfSpeech() {
            Log.d(TAG, "Beginning of speech")
        }

        override fun onRmsChanged(rmsdB: Float) {}

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            isListening = false
            listener?.onListeningEnded()
            Log.d(TAG, "End of speech")
        }

        override fun onError(error: Int) {
            isListening = false
            val errorMessage = getErrorMessage(error)
            Log.e(TAG, "Speech recognition error: $errorMessage ($error)")

            // Restart listening on transient errors in wake word mode
            if (wakeWordMode && (error == SpeechRecognizer.ERROR_NO_MATCH ||
                        error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                        error == SpeechRecognizer.ERROR_CLIENT)) {
                android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                    startWakeWordListening()
                }, 1000)
            } else {
                listener?.onError(errorMessage)
            }
        }

        override fun onResults(results: Bundle?) {
            isListening = false
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val bestMatch = matches?.firstOrNull()?.lowercase()?.trim() ?: ""

            Log.d(TAG, "Speech result: $bestMatch (wakeWordMode=$wakeWordMode)")

            if (wakeWordMode) {
                if (bestMatch.contains(wakeWord)) {
                    Log.d(TAG, "Wake word detected!")
                    listener?.onWakeWordDetected()
                } else {
                    // Keep listening for wake word
                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                        startWakeWordListening()
                    }, 500)
                }
            } else {
                if (bestMatch.isNotEmpty()) {
                    listener?.onCommandRecognized(bestMatch)
                } else {
                    listener?.onError("Could not understand. Please try again.")
                }
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull() ?: ""
            if (partial.isNotEmpty()) {
                listener?.onPartialResult(partial)
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    fun initialize(listener: SpeechListener) {
        this.listener = listener
        wakeWord = settingsManager.getWakeWord().lowercase()
        createRecognizer()
    }

    private fun createRecognizer() {
        speechRecognizer?.destroy()
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
            speechRecognizer?.setRecognitionListener(recognitionListener)
        } else {
            Log.e(TAG, "Speech recognition not available on this device")
        }
    }

    fun startWakeWordListening() {
        if (isListening) return
        wakeWordMode = true
        val intent = buildRecognizerIntent(continuous = true)
        try {
            speechRecognizer?.startListening(intent)
            Log.d(TAG, "Started wake word listening")
        } catch (e: Exception) {
            Log.e(TAG, "Error starting wake word listening", e)
            createRecognizer()
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                speechRecognizer?.startListening(intent)
            }, 500)
        }
    }

    fun startCommandListening() {
        if (isListening) stopListening()
        wakeWordMode = false
        val intent = buildRecognizerIntent(continuous = false)
        try {
            speechRecognizer?.startListening(intent)
            Log.d(TAG, "Started command listening")
        } catch (e: Exception) {
            Log.e(TAG, "Error starting command listening", e)
        }
    }

    fun stopListening() {
        if (isListening) {
            speechRecognizer?.stopListening()
            isListening = false
        }
        wakeWordMode = false
    }

    fun isListening(): Boolean = isListening

    private fun buildRecognizerIntent(continuous: Boolean): Intent {
        val settings = settingsManager.getSettings()
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )

            // Language configuration — try offline first
            if (settings.offlineSpeechPreferred) {
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }

            // Language selection
            val languages = buildList {
                if (settings.useHindi) add("hi-IN")
                if (settings.useEnglish) add("en-IN")
                if (isEmpty()) add("en-US")
            }
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languages.first())
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languages.first())
            putStringArrayListExtra(
                RecognizerIntent.EXTRA_SUPPORTED_LANGUAGES,
                ArrayList(languages)
            )

            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)

            if (continuous) {
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 500L)
            }
        }
    }

    private fun getErrorMessage(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
        SpeechRecognizer.ERROR_CLIENT -> "Client error"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Insufficient permissions"
        SpeechRecognizer.ERROR_NETWORK -> "Network error"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
        SpeechRecognizer.ERROR_NO_MATCH -> "No speech matched"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy"
        SpeechRecognizer.ERROR_SERVER -> "Server error"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected"
        else -> "Unknown error ($error)"
    }

    fun release() {
        stopListening()
        speechRecognizer?.destroy()
        speechRecognizer = null
    }

    companion object {
        private const val TAG = "SpeechRecognitionManager"
    }
}

package com.commanderai.manager

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale
import java.util.UUID

class TextToSpeechManager(
    private val context: Context,
    private val bluetoothManager: BluetoothHeadsetManager
) {

    private var tts: TextToSpeech? = null
    private var isInitialized = false
    private var pendingSpeak: String? = null
    private var currentLanguage: Locale = Locale.ENGLISH
    private var onSpeakDone: (() -> Unit)? = null

    fun initialize(onReady: () -> Unit = {}) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                isInitialized = true
                setLanguage(Locale.ENGLISH)
                tts?.setOnUtteranceProgressListener(utteranceListener)
                Log.d(TAG, "TTS initialized successfully")
                onReady()
                pendingSpeak?.let { speak(it) }
                pendingSpeak = null
            } else {
                Log.e(TAG, "TTS initialization failed with status: $status")
            }
        }
    }

    private val utteranceListener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}

        override fun onDone(utteranceId: String?) {
            if (bluetoothManager.isHeadsetConnected()) {
                bluetoothManager.stopBluetoothAudio()
            }
            onSpeakDone?.invoke()
        }

        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {
            Log.e(TAG, "TTS error for utterance: $utteranceId")
        }
    }

    fun speak(text: String, language: Locale = currentLanguage, onDone: (() -> Unit)? = null) {
        if (!isInitialized) {
            pendingSpeak = text
            return
        }

        onSpeakDone = onDone

        // Route through Bluetooth if connected
        if (bluetoothManager.isHeadsetConnected()) {
            bluetoothManager.routeAudioToBluetooth()
            // Small delay to allow SCO to connect
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                performSpeak(text, language)
            }, 500)
        } else {
            performSpeak(text, language)
        }
    }

    private fun performSpeak(text: String, language: Locale) {
        setLanguage(language)
        val utteranceId = UUID.randomUUID().toString()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        Log.d(TAG, "Speaking: $text in ${language.displayName}")
    }

    fun speakHindi(text: String, onDone: (() -> Unit)? = null) {
        speak(text, Locale("hi", "IN"), onDone)
    }

    fun speakEnglish(text: String, onDone: (() -> Unit)? = null) {
        speak(text, Locale.ENGLISH, onDone)
    }

    fun stop() {
        tts?.stop()
    }

    fun isSpeaking(): Boolean = tts?.isSpeaking == true

    fun setSpeechRate(rate: Float) {
        tts?.setSpeechRate(rate)
    }

    fun setSpeechPitch(pitch: Float) {
        tts?.setPitch(pitch)
    }

    private fun setLanguage(locale: Locale) {
        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            Log.w(TAG, "Language ${locale.displayName} not supported, falling back to English")
            tts?.setLanguage(Locale.ENGLISH)
        }
        currentLanguage = locale
    }

    fun release() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
    }

    companion object {
        private const val TAG = "TextToSpeechManager"
    }
}

package com.commanderai.manager

import android.content.Context
import android.util.Log
import com.commanderai.model.VoiceProfile
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Manages voice profile enrollment and speaker verification.
 *
 * Uses a simple MFCC-inspired energy feature vector for lightweight
 * on-device speaker verification without requiring ML frameworks.
 * For production-quality speaker ID, replace with a TFLite model.
 */
class VoiceProfileManager(private val context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    private var enrolledProfile: VoiceProfile? = null

    init {
        loadProfile()
    }

    fun hasEnrolledProfile(): Boolean = enrolledProfile != null

    fun getEnrolledProfile(): VoiceProfile? = enrolledProfile

    fun startEnrollment(userName: String): EnrollmentSession {
        return EnrollmentSession(userName)
    }

    inner class EnrollmentSession(private val userName: String) {
        private val samples = mutableListOf<FloatArray>()
        val requiredSamples = ENROLLMENT_SAMPLES_NEEDED

        fun addSample(audioData: ShortArray): Boolean {
            val features = extractFeatures(audioData)
            samples.add(features)
            Log.d(TAG, "Added enrollment sample ${samples.size}/$requiredSamples")
            return samples.size >= requiredSamples
        }

        fun getSampleCount(): Int = samples.size

        fun isComplete(): Boolean = samples.size >= requiredSamples

        fun finalize(): VoiceProfile {
            val profile = VoiceProfile(
                id = System.currentTimeMillis().toString(),
                name = userName,
                enrollmentData = samples.toList()
            )
            saveProfile(profile)
            enrolledProfile = profile
            Log.d(TAG, "Voice profile enrolled for $userName with ${samples.size} samples")
            return profile
        }
    }

    fun verifyVoice(audioData: ShortArray): Float {
        val profile = enrolledProfile ?: return 0f
        val inputFeatures = extractFeatures(audioData)

        val similarities = profile.enrollmentData.map { sample ->
            cosineSimilarity(inputFeatures, sample)
        }

        val avgSimilarity = similarities.average().toFloat()
        Log.d(TAG, "Voice verification similarity: $avgSimilarity")
        return avgSimilarity
    }

    fun isVoiceMatch(audioData: ShortArray, threshold: Float = MATCH_THRESHOLD): Boolean {
        if (!hasEnrolledProfile()) return true // No profile — allow all
        return verifyVoice(audioData) >= threshold
    }

    fun deleteProfile() {
        prefs.edit().remove(KEY_PROFILE).apply()
        enrolledProfile = null
        Log.d(TAG, "Voice profile deleted")
    }

    private fun extractFeatures(audioData: ShortArray): FloatArray {
        if (audioData.isEmpty()) return FloatArray(FEATURE_SIZE)

        val frameSize = minOf(audioData.size, 2048)
        val features = FloatArray(FEATURE_SIZE)

        // Energy in frequency bands (simple spectral features)
        val bandSize = frameSize / FEATURE_SIZE
        for (band in 0 until FEATURE_SIZE) {
            var energy = 0.0
            val start = band * bandSize
            val end = minOf(start + bandSize, audioData.size)
            for (i in start until end) {
                val sample = audioData[i].toDouble() / Short.MAX_VALUE
                energy += sample * sample
            }
            features[band] = sqrt(energy / (end - start)).toFloat()
        }

        // Normalize
        val maxVal = features.max()
        if (maxVal > 0) {
            for (i in features.indices) features[i] /= maxVal
        }

        return features
    }

    private fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return 0f
        var dotProduct = 0.0
        var normA = 0.0
        var normB = 0.0
        for (i in a.indices) {
            dotProduct += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }
        val denom = sqrt(normA) * sqrt(normB)
        return if (denom == 0.0) 0f else (dotProduct / denom).toFloat()
    }

    private fun saveProfile(profile: VoiceProfile) {
        // Serialize enrollmentData as List<List<Float>> for JSON
        val serializable = profile.copy(enrollmentData = profile.enrollmentData)
        val data = ProfileData(
            id = serializable.id,
            name = serializable.name,
            enrollmentData = serializable.enrollmentData.map { it.toList() },
            createdAt = serializable.createdAt
        )
        prefs.edit().putString(KEY_PROFILE, gson.toJson(data)).apply()
    }

    private fun loadProfile() {
        val json = prefs.getString(KEY_PROFILE, null) ?: return
        try {
            val type = object : TypeToken<ProfileData>() {}.type
            val data: ProfileData = gson.fromJson(json, type)
            enrolledProfile = VoiceProfile(
                id = data.id,
                name = data.name,
                enrollmentData = data.enrollmentData.map { it.toFloatArray() },
                createdAt = data.createdAt
            )
            Log.d(TAG, "Loaded voice profile for ${enrolledProfile?.name}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to load voice profile", e)
        }
    }

    private data class ProfileData(
        val id: String,
        val name: String,
        val enrollmentData: List<List<Float>>,
        val createdAt: Long
    )

    companion object {
        private const val TAG = "VoiceProfileManager"
        private const val PREFS_NAME = "voice_profile_prefs"
        private const val KEY_PROFILE = "enrolled_profile"
        private const val ENROLLMENT_SAMPLES_NEEDED = 5
        private const val FEATURE_SIZE = 32
        private const val MATCH_THRESHOLD = 0.72f
    }
}

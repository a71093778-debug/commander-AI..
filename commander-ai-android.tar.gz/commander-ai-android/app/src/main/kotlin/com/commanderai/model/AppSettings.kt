package com.commanderai.model

data class AppSettings(
    val isAssistantEnabled: Boolean = true,
    val wakeWord: String = "hello commander",
    val useHindi: Boolean = true,
    val useEnglish: Boolean = true,
    val useBluetooth: Boolean = true,
    val voiceProfileEnabled: Boolean = false,
    val startOnBoot: Boolean = true,
    val speakNotifications: Boolean = true,
    val continuousListening: Boolean = true,
    val offlineSpeechPreferred: Boolean = true,
    val speechRate: Float = 1.0f,
    val speechPitch: Float = 1.0f
)

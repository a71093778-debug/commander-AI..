package com.commanderai.model

enum class CommandType {
    CALL_CONTACT,
    OPEN_APP,
    READ_NOTIFICATIONS,
    READ_SMS,
    READ_MISSED_CALLS,
    BATTERY_STATUS,
    TIME_DATE,
    FLASHLIGHT_ON,
    FLASHLIGHT_OFF,
    FLASHLIGHT_TOGGLE,
    BLUETOOTH_STATUS,
    WIFI_STATUS,
    UNKNOWN
}

data class Command(
    val type: CommandType,
    val rawText: String,
    val parameter: String? = null
)

data class CommandResult(
    val success: Boolean,
    val response: String,
    val error: String? = null
)

data class VoiceProfile(
    val id: String,
    val name: String,
    val enrollmentData: List<FloatArray>,
    val createdAt: Long = System.currentTimeMillis()
)

data class ContactInfo(
    val name: String,
    val phoneNumber: String
)

data class SmsMessage(
    val sender: String,
    val body: String,
    val timestamp: Long
)

data class MissedCall(
    val number: String,
    val name: String?,
    val timestamp: Long
)

data class NotificationInfo(
    val appName: String,
    val title: String?,
    val text: String?,
    val timestamp: Long
)

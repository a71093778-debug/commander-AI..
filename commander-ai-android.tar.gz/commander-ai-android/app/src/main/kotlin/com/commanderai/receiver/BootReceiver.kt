package com.commanderai.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.commanderai.manager.SettingsManager
import com.commanderai.service.VoiceAssistantService

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            val settingsManager = SettingsManager(context)
            if (settingsManager.isStartOnBoot() && settingsManager.isAssistantEnabled()) {
                Log.d(TAG, "Boot complete — starting Commander AI service")
                val serviceIntent = Intent(context, VoiceAssistantService::class.java)
                context.startForegroundService(serviceIntent)
            }
        }
    }

    companion object {
        private const val TAG = "BootReceiver"
    }
}

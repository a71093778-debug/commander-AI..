package com.commanderai.service

import android.content.pm.PackageManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.commanderai.model.NotificationInfo

class CommanderNotificationService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        if (sbn.isOngoing) return // Skip persistent notifications
        val info = buildNotificationInfo(sbn)
        activeNotifications[sbn.key] = info
        Log.d(TAG, "Notification posted: ${info.appName} — ${info.title}")
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        sbn ?: return
        activeNotifications.remove(sbn.key)
    }

    private fun buildNotificationInfo(sbn: StatusBarNotification): NotificationInfo {
        val pm = applicationContext.packageManager
        val appName = try {
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: PackageManager.NameNotFoundException) {
            sbn.packageName
        }

        val extras = sbn.notification?.extras
        val title = extras?.getCharSequence("android.title")?.toString()
        val text = extras?.getCharSequence("android.text")?.toString()

        return NotificationInfo(
            appName = appName,
            title = title,
            text = text,
            timestamp = sbn.postTime
        )
    }

    companion object {
        private const val TAG = "CommanderNotifService"

        private val activeNotifications = LinkedHashMap<String, NotificationInfo>()

        fun getActiveNotifications(): List<NotificationInfo> {
            return activeNotifications.values
                .sortedByDescending { it.timestamp }
                .take(20)
        }

        fun clearAll() {
            activeNotifications.clear()
        }
    }
}

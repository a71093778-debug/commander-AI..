package com.commanderai.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.*
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.commanderai.R
import com.commanderai.manager.*
import com.commanderai.ui.MainActivity
import java.util.Locale

class VoiceAssistantService : LifecycleService() {

    private lateinit var settingsManager: SettingsManager
    private lateinit var bluetoothManager: BluetoothHeadsetManager
    private lateinit var ttsManager: TextToSpeechManager
    private lateinit var speechManager: SpeechRecognitionManager
    private lateinit var commandProcessor: CommandProcessor
    private lateinit var voiceProfileManager: VoiceProfileManager

    private var state = ServiceState.IDLE
    private val mainHandler = Handler(Looper.getMainLooper())

    enum class ServiceState { IDLE, LISTENING_FOR_WAKE_WORD, LISTENING_FOR_COMMAND, SPEAKING, PROCESSING }

    companion object {
        const val ACTION_STATE_CHANGED = "com.commanderai.STATE_CHANGED"
        const val ACTION_TRANSCRIPT = "com.commanderai.TRANSCRIPT"
        const val ACTION_RESPONSE = "com.commanderai.RESPONSE"
        const val EXTRA_STATE = "state"
        const val EXTRA_TEXT = "text"
        const val CHANNEL_ID = "commander_ai_channel"
        const val NOTIFICATION_ID = 1001
        private const val TAG = "VoiceAssistantService"
    }

    private val bluetoothListener = object : BluetoothHeadsetManager.BluetoothHeadsetListener {
        override fun onHeadsetConnected() {
            Log.d(TAG, "BT headset connected")
            speak("Bluetooth headset connected. I will speak through it.")
        }
        override fun onHeadsetDisconnected() {
            Log.d(TAG, "BT headset disconnected")
        }
        override fun onAudioRouteChanged(throughBluetooth: Boolean) {
            Log.d(TAG, "Audio route: bluetooth=$throughBluetooth")
        }
    }

    private val speechListener = object : SpeechRecognitionManager.SpeechListener {
        override fun onWakeWordDetected() {
            Log.d(TAG, "Wake word detected")
            setState(ServiceState.LISTENING_FOR_COMMAND)
            broadcastState("wake_word_detected")
            speak("Yes?") { speechManager.startCommandListening() }
        }

        override fun onCommandRecognized(text: String) {
            Log.d(TAG, "Command: $text")
            setState(ServiceState.PROCESSING)
            broadcastTranscript(text)
            processCommand(text)
        }

        override fun onPartialResult(text: String) {
            broadcastTranscript(text)
        }

        override fun onError(error: String) {
            Log.w(TAG, "Speech error: $error")
            if (state == ServiceState.LISTENING_FOR_COMMAND) {
                speak("Sorry, I didn't catch that.") { resumeWakeWordListening() }
            } else {
                resumeWakeWordListening()
            }
        }

        override fun onListeningStarted() {
            broadcastState(
                if (state == ServiceState.LISTENING_FOR_COMMAND) "listening_command" else "listening_wake"
            )
        }

        override fun onListeningEnded() {}
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "Service created")
        initializeComponents()
        createNotificationChannel()

        // Android 14 (API 34) requires passing the foreground service type explicitly
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                buildNotification("Initializing…"),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, buildNotification("Initializing…"))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        Log.d(TAG, "Service started")
        ttsManager.initialize {
            speak("Commander AI is ready. Say Hello Commander to activate.") {
                resumeWakeWordListening()
            }
        }
        return START_STICKY
    }

    private fun initializeComponents() {
        settingsManager = SettingsManager(this)
        bluetoothManager = BluetoothHeadsetManager(this)
        ttsManager = TextToSpeechManager(this, bluetoothManager)
        speechManager = SpeechRecognitionManager(this, settingsManager)
        commandProcessor = CommandProcessor(this)
        voiceProfileManager = VoiceProfileManager(this)

        bluetoothManager.initialize(bluetoothListener)
        speechManager.initialize(speechListener)
    }

    private fun processCommand(text: String) {
        val command = commandProcessor.parseCommand(text)
        val result = commandProcessor.execute(command)

        broadcastResponse(result.response)
        updateNotification(result.response.take(80))

        val responseLanguage = if (containsHindi(text)) Locale("hi", "IN") else Locale.ENGLISH
        speak(result.response, responseLanguage) { resumeWakeWordListening() }
    }

    private fun resumeWakeWordListening() {
        if (!settingsManager.isAssistantEnabled()) return
        setState(ServiceState.LISTENING_FOR_WAKE_WORD)
        updateNotification("Listening for \"${settingsManager.getWakeWord()}\"…")
        mainHandler.postDelayed({ speechManager.startWakeWordListening() }, 300)
    }

    private fun speak(text: String, language: Locale = Locale.ENGLISH, onDone: (() -> Unit)? = null) {
        setState(ServiceState.SPEAKING)
        ttsManager.speak(text, language, onDone)
    }

    private fun setState(newState: ServiceState) { state = newState }

    private fun broadcastState(s: String) =
        sendBroadcast(Intent(ACTION_STATE_CHANGED).apply { putExtra(EXTRA_STATE, s) })

    private fun broadcastTranscript(text: String) =
        sendBroadcast(Intent(ACTION_TRANSCRIPT).apply { putExtra(EXTRA_TEXT, text) })

    private fun broadcastResponse(text: String) =
        sendBroadcast(Intent(ACTION_RESPONSE).apply { putExtra(EXTRA_TEXT, text) })

    private fun containsHindi(text: String) = text.any { it.code in 0x0900..0x097F }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Commander AI Assistant",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Commander AI is running in the background"
            setShowBadge(false)
        }
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Commander AI")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun updateNotification(text: String) {
        (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Service destroyed")
        speechManager.release()
        ttsManager.release()
        bluetoothManager.release()
    }
}

package com.commanderai.tile

import android.content.Intent
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.util.Log
import com.commanderai.manager.SettingsManager
import com.commanderai.service.VoiceAssistantService

class CommanderQuickSettingsTile : TileService() {

    private lateinit var settingsManager: SettingsManager

    override fun onCreate() {
        super.onCreate()
        settingsManager = SettingsManager(this)
    }

    override fun onStartListening() {
        super.onStartListening()
        updateTile()
    }

    override fun onClick() {
        super.onClick()
        val enabled = settingsManager.isAssistantEnabled()
        settingsManager.setAssistantEnabled(!enabled)

        if (!enabled) {
            // Enable — start service
            val intent = Intent(this, VoiceAssistantService::class.java)
            startForegroundService(intent)
            Log.d(TAG, "QS tile: started assistant service")
        } else {
            // Disable — stop service
            val intent = Intent(this, VoiceAssistantService::class.java)
            stopService(intent)
            Log.d(TAG, "QS tile: stopped assistant service")
        }

        updateTile()
    }

    private fun updateTile() {
        val tile = qsTile ?: return
        val enabled = settingsManager.isAssistantEnabled()
        tile.state = if (enabled) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "Commander AI"
        tile.subtitle = if (enabled) "Active" else "Inactive"
        tile.updateTile()
    }

    companion object {
        private const val TAG = "CommanderQSTile"
    }
}

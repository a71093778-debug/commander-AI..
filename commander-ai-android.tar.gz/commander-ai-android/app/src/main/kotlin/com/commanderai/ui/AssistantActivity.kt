package com.commanderai.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import androidx.appcompat.app.AppCompatActivity
import com.commanderai.R
import com.commanderai.databinding.ActivityAssistantBinding
import com.commanderai.service.VoiceAssistantService

class AssistantActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAssistantBinding
    private val history = mutableListOf<Pair<String, String>>() // command to response

    private val assistantReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                VoiceAssistantService.ACTION_STATE_CHANGED -> {
                    handleStateChange(intent.getStringExtra(VoiceAssistantService.EXTRA_STATE) ?: "")
                }
                VoiceAssistantService.ACTION_TRANSCRIPT -> {
                    val text = intent.getStringExtra(VoiceAssistantService.EXTRA_TEXT) ?: ""
                    showTranscript(text)
                }
                VoiceAssistantService.ACTION_RESPONSE -> {
                    val text = intent.getStringExtra(VoiceAssistantService.EXTRA_TEXT) ?: ""
                    showResponse(text)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAssistantBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Assistant"

        binding.toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        binding.fabMicLarge.setOnClickListener {
            // Manually trigger listening
            val intent = Intent(this, VoiceAssistantService::class.java)
            startForegroundService(intent)
        }
    }

    override fun onResume() {
        super.onResume()
        val filter = IntentFilter().apply {
            addAction(VoiceAssistantService.ACTION_STATE_CHANGED)
            addAction(VoiceAssistantService.ACTION_TRANSCRIPT)
            addAction(VoiceAssistantService.ACTION_RESPONSE)
        }
        registerReceiver(assistantReceiver, filter, RECEIVER_NOT_EXPORTED)
        setIdleState()
    }

    override fun onPause() {
        super.onPause()
        unregisterReceiver(assistantReceiver)
    }

    private fun handleStateChange(state: String) {
        when (state) {
            "wake_word_detected", "listening_command" -> {
                setListeningState()
            }
            "listening_wake" -> {
                setIdleState()
            }
        }
    }

    private fun setIdleState() {
        binding.fabMicLarge.clearAnimation()
        binding.tvAssistantStatus.text = "Say \"Hello Commander\""
        binding.lottieWave.visibility = View.INVISIBLE
        binding.tvTranscriptLive.visibility = View.GONE
    }

    private fun setListeningState() {
        val pulse = AnimationUtils.loadAnimation(this, R.anim.pulse)
        binding.fabMicLarge.startAnimation(pulse)
        binding.tvAssistantStatus.text = "Listening..."
        binding.lottieWave.visibility = View.VISIBLE
        binding.tvTranscriptLive.visibility = View.VISIBLE
        binding.tvTranscriptLive.text = ""
    }

    private fun showTranscript(text: String) {
        binding.tvTranscriptLive.text = text
        binding.tvTranscriptLive.visibility = View.VISIBLE
    }

    private fun showResponse(text: String) {
        binding.tvTranscriptLive.visibility = View.GONE
        addHistoryItem(binding.tvTranscriptLive.text.toString(), text)
        binding.tvLastResponse.text = text
        binding.cardResponse.visibility = View.VISIBLE
    }

    private fun addHistoryItem(command: String, response: String) {
        if (command.isNotBlank() && response.isNotBlank()) {
            history.add(0, command to response)
        }
    }
}

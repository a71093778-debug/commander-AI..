package com.commanderai.ui

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.ColorStateList
import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.commanderai.R
import com.commanderai.databinding.ActivityMainBinding
import com.commanderai.manager.SettingsManager
import com.commanderai.service.VoiceAssistantService

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var settingsManager: SettingsManager
    private var isAnimating = false

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                VoiceAssistantService.ACTION_STATE_CHANGED -> {
                    updateListeningState(
                        intent.getStringExtra(VoiceAssistantService.EXTRA_STATE) ?: ""
                    )
                }
                VoiceAssistantService.ACTION_TRANSCRIPT -> {
                    val text = intent.getStringExtra(VoiceAssistantService.EXTRA_TEXT) ?: ""
                    binding.tvTranscript.text = text
                    binding.tvTranscript.visibility = View.VISIBLE
                    binding.tvResponse.visibility = View.GONE
                }
                VoiceAssistantService.ACTION_RESPONSE -> {
                    val text = intent.getStringExtra(VoiceAssistantService.EXTRA_TEXT) ?: ""
                    binding.tvResponse.text = text
                    binding.tvResponse.visibility = View.VISIBLE
                    binding.tvTranscript.visibility = View.GONE
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        settingsManager = SettingsManager(this)
        setSupportActionBar(binding.toolbar)
        setupClickListeners()
    }

    override fun onResume() {
        super.onResume()
        registerStateReceiver()
        updateUiFromSettings()
    }

    override fun onPause() {
        super.onPause()
        try { unregisterReceiver(stateReceiver) } catch (_: IllegalArgumentException) {}
    }

    private fun setupClickListeners() {
        binding.fabMic.setOnClickListener { toggleAssistant() }
        binding.fabMic.setOnLongClickListener {
            openAssistantScreen()
            true
        }
        binding.btnAssistant.setOnClickListener { openAssistantScreen() }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        binding.btnVoiceProfile.setOnClickListener {
            startActivity(Intent(this, VoiceProfileActivity::class.java))
        }
        binding.switchAssistant.setOnCheckedChangeListener { _, checked ->
            settingsManager.setAssistantEnabled(checked)
            if (checked) startAssistantService() else stopAssistantService()
            updateFabState(checked)
        }
    }

    private fun toggleAssistant() {
        val enabled = settingsManager.isAssistantEnabled()
        settingsManager.setAssistantEnabled(!enabled)
        binding.switchAssistant.isChecked = !enabled
        if (!enabled) {
            startAssistantService()
            Toast.makeText(this, "Commander AI activated", Toast.LENGTH_SHORT).show()
        } else {
            stopAssistantService()
            Toast.makeText(this, "Commander AI deactivated", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openAssistantScreen() {
        startActivity(Intent(this, AssistantActivity::class.java))
    }

    private fun startAssistantService() {
        startForegroundService(Intent(this, VoiceAssistantService::class.java))
    }

    private fun stopAssistantService() {
        stopService(Intent(this, VoiceAssistantService::class.java))
        binding.tvResponse.visibility = View.GONE
        binding.tvTranscript.visibility = View.GONE
    }

    private fun registerStateReceiver() {
        val filter = IntentFilter().apply {
            addAction(VoiceAssistantService.ACTION_STATE_CHANGED)
            addAction(VoiceAssistantService.ACTION_TRANSCRIPT)
            addAction(VoiceAssistantService.ACTION_RESPONSE)
        }
        registerReceiver(stateReceiver, filter, RECEIVER_NOT_EXPORTED)
    }

    private fun updateListeningState(state: String) {
        when (state) {
            "wake_word_detected", "listening_command" -> {
                animateMicPulse(true)
                binding.tvStatus.text = "Listening for command…"
                binding.tvStatus.setTextColor(getColor(R.color.status_listening))
            }
            "listening_wake" -> {
                animateMicPulse(false)
                binding.tvStatus.text = "Say \"Hello Commander\""
                binding.tvStatus.setTextColor(getColor(R.color.status_idle))
            }
        }
    }

    private fun updateUiFromSettings() {
        val enabled = settingsManager.isAssistantEnabled()
        binding.switchAssistant.isChecked = enabled
        updateFabState(enabled)
        binding.tvStatus.text = if (enabled) "Say \"Hello Commander\"" else "Assistant is off"
        binding.tvStatus.setTextColor(
            getColor(if (enabled) R.color.status_idle else R.color.text_secondary)
        )
    }

    private fun updateFabState(enabled: Boolean) {
        val iconRes = if (enabled) R.drawable.ic_mic else R.drawable.ic_mic_off
        val colorRes = if (enabled) R.color.fab_active else R.color.fab_inactive
        // FloatingActionButton uses setImageDrawable / backgroundTintList — not setImageResource/setBackgroundColor
        binding.fabMic.setImageDrawable(ContextCompat.getDrawable(this, iconRes))
        binding.fabMic.backgroundTintList = ColorStateList.valueOf(getColor(colorRes))
    }

    private fun animateMicPulse(start: Boolean) {
        if (start && !isAnimating) {
            isAnimating = true
            val pulse = AnimationUtils.loadAnimation(this, R.anim.pulse)
            binding.fabMic.startAnimation(pulse)
        } else if (!start) {
            isAnimating = false
            binding.fabMic.clearAnimation()
        }
    }
}

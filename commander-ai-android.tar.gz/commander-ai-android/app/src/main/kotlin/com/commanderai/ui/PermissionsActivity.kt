package com.commanderai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.commanderai.databinding.ActivityPermissionsBinding

class PermissionsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPermissionsBinding

    private val requiredPermissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.CALL_PHONE,
        Manifest.permission.READ_CALL_LOG,
        Manifest.permission.READ_SMS,
        Manifest.permission.POST_NOTIFICATIONS,
        Manifest.permission.BLUETOOTH_CONNECT
    )

    private val requestAllPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { updatePermissionsUi() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Permissions"
        binding.toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        setupListeners()
        updatePermissionsUi()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionsUi()
    }

    private fun setupListeners() {
        binding.btnGrantAll.setOnClickListener {
            requestAllPermissions.launch(requiredPermissions)
        }
        binding.btnOpenSettings.setOnClickListener {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", packageName, null)
            })
        }
        binding.btnNotificationListener.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
    }

    private fun updatePermissionsUi() {
        val granted = requiredPermissions.count { isGranted(it) }
        val total = requiredPermissions.size

        binding.tvPermissionSummary.text = "$granted of $total permissions granted"
        binding.progressPermissions.progress = (granted * 100) / total
        binding.btnGrantAll.isEnabled = granted < total

        setStatus(binding.tvMicStatus, isGranted(Manifest.permission.RECORD_AUDIO))
        setStatus(binding.tvContactsStatus, isGranted(Manifest.permission.READ_CONTACTS))
        setStatus(binding.tvCallStatus, isGranted(Manifest.permission.CALL_PHONE))
        setStatus(binding.tvCallLogStatus, isGranted(Manifest.permission.READ_CALL_LOG))
        setStatus(binding.tvSmsStatus, isGranted(Manifest.permission.READ_SMS))
        setStatus(binding.tvNotifStatus, isGranted(Manifest.permission.POST_NOTIFICATIONS))
        setStatus(binding.tvBtStatus, isGranted(Manifest.permission.BLUETOOTH_CONNECT))
    }

    private fun isGranted(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun setStatus(view: TextView, granted: Boolean) {
        view.text = if (granted) "✓ Granted" else "✗ Denied"
        view.setTextColor(
            if (granted) getColor(android.R.color.holo_green_dark)
            else getColor(android.R.color.holo_red_dark)
        )
    }
}

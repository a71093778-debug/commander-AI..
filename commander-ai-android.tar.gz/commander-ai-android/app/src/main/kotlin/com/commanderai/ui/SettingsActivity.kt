package com.commanderai.ui

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AppCompatActivity
import com.commanderai.R
import com.commanderai.databinding.ActivitySettingsBinding
import com.commanderai.manager.SettingsManager
import com.commanderai.model.AppSettings
import com.commanderai.service.VoiceAssistantService
import com.google.android.material.slider.Slider

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var settingsManager: SettingsManager
    private lateinit var currentSettings: AppSettings

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Settings"
        binding.toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        settingsManager = SettingsManager(this)
        currentSettings = settingsManager.getSettings()

        loadSettingsIntoUi()
        setupListeners()
    }

    override fun onPause() {
        super.onPause()
        saveSettings()
    }

    private fun loadSettingsIntoUi() {
        binding.switchAssistantEnable.isChecked = currentSettings.isAssistantEnabled
        binding.etWakeWord.setText(currentSettings.wakeWord)
        binding.switchHindi.isChecked = currentSettings.useHindi
        binding.switchEnglish.isChecked = currentSettings.useEnglish
        binding.switchBluetooth.isChecked = currentSettings.useBluetooth
        binding.switchVoiceProfile.isChecked = currentSettings.voiceProfileEnabled
        binding.switchStartBoot.isChecked = currentSettings.startOnBoot
        binding.switchNotifications.isChecked = currentSettings.speakNotifications
        binding.switchContinuous.isChecked = currentSettings.continuousListening
        binding.switchOfflineSpeech.isChecked = currentSettings.offlineSpeechPreferred
        binding.sliderSpeechRate.value = currentSettings.speechRate
        binding.sliderSpeechPitch.value = currentSettings.speechPitch
    }

    private fun setupListeners() {
        binding.btnNotificationAccess.setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }

        binding.btnVoiceProfile.setOnClickListener {
            startActivity(Intent(this, VoiceProfileActivity::class.java))
        }

        binding.btnPermissions.setOnClickListener {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }

        binding.sliderSpeechRate.addOnChangeListener { _, value, _ ->
            binding.tvSpeechRateValue.text = String.format("%.1fx", value)
        }

        binding.sliderSpeechPitch.addOnChangeListener { _, value, _ ->
            binding.tvSpeechPitchValue.text = String.format("%.1f", value)
        }
    }

    private fun saveSettings() {
        val updated = AppSettings(
            isAssistantEnabled = binding.switchAssistantEnable.isChecked,
            wakeWord = binding.etWakeWord.text.toString().lowercase().trim()
                .ifBlank { "hello commander" },
            useHindi = binding.switchHindi.isChecked,
            useEnglish = binding.switchEnglish.isChecked,
            useBluetooth = binding.switchBluetooth.isChecked,
            voiceProfileEnabled = binding.switchVoiceProfile.isChecked,
            startOnBoot = binding.switchStartBoot.isChecked,
            speakNotifications = binding.switchNotifications.isChecked,
            continuousListening = binding.switchContinuous.isChecked,
            offlineSpeechPreferred = binding.switchOfflineSpeech.isChecked,
            speechRate = binding.sliderSpeechRate.value,
            speechPitch = binding.sliderSpeechPitch.value
        )
        settingsManager.saveSettings(updated)

        // Restart service to apply changes
        val svcIntent = Intent(this, VoiceAssistantService::class.java)
        if (updated.isAssistantEnabled) {
            stopService(svcIntent)
            startForegroundService(svcIntent)
        } else {
            stopService(svcIntent)
        }
    }
}

package com.commanderai.ui

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.commanderai.R
import com.commanderai.databinding.ActivityVoiceProfileBinding
import com.commanderai.manager.VoiceProfileManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.*

class VoiceProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityVoiceProfileBinding
    private lateinit var profileManager: VoiceProfileManager
    private var enrollmentSession: VoiceProfileManager.EnrollmentSession? = null

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var isRecording = false
    private var audioRecord: AudioRecord? = null

    private val requestPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startEnrollmentSession()
        else showPermissionDenied()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVoiceProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Voice Profile"
        binding.toolbar.setNavigationOnClickListener { onBackPressedDispatcher.onBackPressed() }

        profileManager = VoiceProfileManager(this)
        updateProfileStatus()
        setupListeners()
    }

    private fun setupListeners() {
        binding.btnEnroll.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED
            ) {
                startEnrollmentSession()
            } else {
                requestPermission.launch(Manifest.permission.RECORD_AUDIO)
            }
        }

        binding.btnRecordSample.setOnClickListener {
            if (!isRecording) recordSample()
        }

        binding.btnDeleteProfile.setOnClickListener {
            confirmDeleteProfile()
        }
    }

    private fun startEnrollmentSession() {
        val name = binding.etProfileName.text.toString().trim().ifBlank { "User" }
        enrollmentSession = profileManager.startEnrollment(name)
        binding.cardEnrollment.visibility = View.VISIBLE
        binding.btnEnroll.isEnabled = false
        updateSampleProgress(0)
        binding.tvEnrollmentStatus.text = "Tap 'Record Sample' and say your wake phrase clearly"
    }

    private fun recordSample() {
        isRecording = true
        binding.btnRecordSample.isEnabled = false
        binding.tvEnrollmentStatus.text = "Recording... speak now"
        binding.progressRecording.visibility = View.VISIBLE

        scope.launch {
            val audioData = withContext(Dispatchers.IO) { recordAudio(durationMs = 2000) }
            isRecording = false
            binding.progressRecording.visibility = View.GONE
            binding.btnRecordSample.isEnabled = true

            val session = enrollmentSession ?: return@launch
            val complete = session.addSample(audioData)
            updateSampleProgress(session.getSampleCount())

            if (complete) {
                val profile = session.finalize()
                binding.tvEnrollmentStatus.text =
                    "Voice profile saved for ${profile.name}!"
                binding.cardEnrollment.visibility = View.GONE
                binding.btnEnroll.isEnabled = true
                enrollmentSession = null
                updateProfileStatus()
            } else {
                val remaining = session.requiredSamples - session.getSampleCount()
                binding.tvEnrollmentStatus.text =
                    "Good! $remaining more sample${if (remaining != 1) "s" else ""} needed."
            }
        }
    }

    private fun recordAudio(durationMs: Int): ShortArray {
        val sampleRate = 16000
        val bufferSize = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val totalSamples = (sampleRate * durationMs) / 1000
        val data = ShortArray(totalSamples)

        val recorder = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )

        return try {
            recorder.startRecording()
            var offset = 0
            while (offset < totalSamples) {
                val read = recorder.read(data, offset, minOf(bufferSize / 2, totalSamples - offset))
                if (read < 0) break
                offset += read
            }
            recorder.stop()
            data
        } finally {
            recorder.release()
        }
    }

    private fun updateSampleProgress(count: Int) {
        val total = 5
        binding.progressEnrollment.progress = (count * 100) / total
        binding.tvSampleCount.text = "$count / $total samples"
    }

    private fun updateProfileStatus() {
        val hasProfile = profileManager.hasEnrolledProfile()
        val profile = profileManager.getEnrolledProfile()

        if (hasProfile && profile != null) {
            binding.tvProfileStatus.text = "Profile enrolled: ${profile.name}"
            binding.tvProfileStatus.setTextColor(getColor(R.color.status_active))
            binding.btnDeleteProfile.visibility = View.VISIBLE
            binding.btnEnroll.text = "Re-enroll"
        } else {
            binding.tvProfileStatus.text = "No voice profile enrolled"
            binding.tvProfileStatus.setTextColor(getColor(R.color.status_idle))
            binding.btnDeleteProfile.visibility = View.GONE
            binding.btnEnroll.text = "Enroll Voice"
        }
    }

    private fun confirmDeleteProfile() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete Voice Profile")
            .setMessage("Are you sure you want to delete your voice profile?")
            .setPositiveButton("Delete") { _, _ ->
                profileManager.deleteProfile()
                updateProfileStatus()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPermissionDenied() {
        binding.tvEnrollmentStatus.text = "Microphone permission required for enrollment"
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}

#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# Commander AI — Release Build Script
# ─────────────────────────────────────────────────────────────────────────────
# Prerequisites:
#   • Android SDK installed, ANDROID_HOME set
#   • Java 17+ on PATH
#   • keystore.properties present (copy keystore.properties.template and fill in)
#
# Usage:
#   chmod +x build-release.sh
#   ./build-release.sh
# ─────────────────────────────────────────────────────────────────────────────

set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
OUTPUT_DIR="$PROJECT_DIR/release-output"
APK_NAME="CommanderAI-v1.0.0-release.apk"

echo "═══════════════════════════════════════════"
echo "  Commander AI  —  Release Build"
echo "═══════════════════════════════════════════"

# ── Step 1: Check prerequisites ───────────────────────────────────────────
if [ ! -f "$PROJECT_DIR/keystore.properties" ]; then
  echo "❌  keystore.properties not found."
  echo "    Copy keystore.properties.template → keystore.properties and fill in your values."
  echo ""
  echo "    To generate a new keystore, run:"
  echo "    keytool -genkeypair -v -storetype PKCS12 \\"
  echo "            -keystore commander-ai-release.keystore \\"
  echo "            -alias commander-ai \\"
  echo "            -keyalg RSA -keysize 2048 \\"
  echo "            -validity 10000"
  exit 1
fi

# ── Step 2: Clean ────────────────────────────────────────────────────────
echo "▶  Cleaning previous build…"
"$PROJECT_DIR/gradlew" clean --quiet

# ── Step 3: Lint ─────────────────────────────────────────────────────────
echo "▶  Running lint…"
"$PROJECT_DIR/gradlew" :app:lint --quiet
echo "    Lint report: app/build/reports/lint-results.html"

# ── Step 4: Build release APK ────────────────────────────────────────────
echo "▶  Assembling release APK…"
"$PROJECT_DIR/gradlew" :app:assembleRelease

# ── Step 5: Collect output ───────────────────────────────────────────────
mkdir -p "$OUTPUT_DIR"
cp "$PROJECT_DIR/app/build/outputs/apk/release/app-release.apk" \
   "$OUTPUT_DIR/$APK_NAME"

echo ""
echo "✅  Build successful!"
echo "    APK:  $OUTPUT_DIR/$APK_NAME"
echo "    Size: $(du -sh "$OUTPUT_DIR/$APK_NAME" | cut -f1)"
echo ""
echo "  Install on connected device:"
echo "    adb install -r \"$OUTPUT_DIR/$APK_NAME\""
